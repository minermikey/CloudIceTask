﻿using System.ComponentModel.DataAnnotations;

namespace IceTaskHandIn.Cars
{
    public class Car
    {

        [Key]
        public int RenterID{ get; set; } // this is the primary key
        public string RenterName { get; set; }
        public string  RentersAge { get; set; }
        public string  make { get; set; }
        public string  model { get; set; }
        public DateTime RentedDate { get; set; }
        public Car() { }



    }
}
